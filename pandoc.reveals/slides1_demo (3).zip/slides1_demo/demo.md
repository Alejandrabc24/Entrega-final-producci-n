% Top tips for creating accessible EPUB 3 files
% Alejandra Bermúdez Cardona
% Marzo de 2022


![Presentaciones web](web.jpg)

# Part 1

## Logical reading order

**Ensure all text follows a logical reading order**:

  - Text must not be presented as images, be reordered by CSS, or require scripting to be accessed.
  - Use structural markup to define the natural reading order of the primary narrative and to distinguish secondary material such as footnotes, references, figures, and other auxiliary content.

## Separate presentation and content

**Visual reading is only one way of accessing content**:

  - Do not use visual-only cues such as colored text, font size or positioning as the only clue to the meaning or importance of a word or section.
  - Do not use tables or pictures of text to control the appearance of the content.
  - The meaning of the content should be the same both with and without any styles or formatting applied.


## Provide complete navigation

**Include a complete table of contents**:

  - Include a complete table of contents in the front matter and consider smaller tables of contents at the start of each section.
  - This is particularly important for academic, educational, and other complex texts.

### Ejemplo de tabla

| Elemento      | Descripción                                   |
|---------------|-----------------------------------------------|
| Elemento 1    | Esto es una descripción                       |
| Elemento 2    | Esto es una descripción                       |
| Elemento 3    | Esto es una descripción                       |
| Elemento 4    | Esto es una descripción                       |



## Create meaningful structure wherever possible

**Create a structure by using numbered headings**:

  - For other tagged structures, specify their content with the epub:type attribute.
  - For example, the tag that contains the preface of a book might look like `<section epub:type=”preface”>`.
  
# Part 2

## Define the content of each tag

**Include semantic information to describe the content of a tag**:

  - A section tag for the table of contents would look like `<section epub:type=”toc”>` or a list of definitions in a glossary would be tagged with `<dl epub:type=”glossary”>`.
  - Use the EPUB 3 Structural Semantics Vocabulary as defined at [http://idpf.org/epub/vocab/structure/](http://idpf.org/epub/vocab/structure/) to identify content.

## Use images only for pictures

**Any content embedded in an image is not available to visually impaired readers**:

  - If the textual contents of a table or image are required for comprehension of the document, use proper and complete markup for text and tabular data.
  - If images of text are unavoidable, provide a description and transcription of the text and use accessible SVG.

## Include page numbers

**Page numbers are the way many people navigate within a book**:

  - For any book with a print equivalent, use the `epub:type=”pagebreak”` attribute to designate page numbers.
  - Include the ISBN of the source of the page numbers in the package metadata for the book.


# Part 3

## Provide alternative access to media content

**Make sure the native controls for video and audio content are enabled by default**:

  - Provide fallback options such as captions or descriptions for video and transcripts for audio.

## Make interactive content accessible

**Interactive content using JavaScript or SVG should be accessible**:

  - All custom controls should fully implement ARIA roles, states, and properties, as appropriate.